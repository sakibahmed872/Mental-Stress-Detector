package com.example.mentalstressdetector;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.lzyzsd.circleprogress.ArcProgress;

public class result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        ArcProgress arcProgress =  findViewById(R.id.arc_progress);

        arcProgress.setProgress(60);
    }
}
